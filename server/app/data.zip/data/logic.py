# # import pytz
# # from datetime import datetime, timedelta

# # # Define the last hour's start and end times in UTC
# # now = datetime.utcnow()
# # start_time_utc = now.replace(minute=0, second=0, microsecond=0) - timedelta(hours=1)
# # end_time_utc = now.replace(minute=0, second=0, microsecond=0)

# # # Define the business hours for each store
# # store_hours = {
# #     "1481966498820158979": [
# #         {"day": 4, "start_time": "00:00:00", "end_time": "00:10:00"},
# #         {"day": 2, "start_time": "00:00:00", "end_time": "00:10:00"},
# #         {"day": 0, "start_time": "00:00:00", "end_time": "00:10:00"},
# #     ],
# #     # Add more stores here...
# # }

# # # Define the timezones for each store
# # store_timezones = {
# #     "1481966498820158979": "Asia/Beirut",
# #     "5415949628544298339": "America/Boise",
# #     "3408529570017053440": "America/Denver"
# #     # Add more stores here...
# # }

# # # Loop over all stores
# # for store_id in store_hours:
# #     # Get the store's timezone
# #     timezone_str = store_timezones[store_id]
# #     timezone = pytz.timezone(timezone_str)

# #     # Convert the last hour's start and end times to the store's local time
# #     start_time_local = start_time_utc.astimezone(timezone)
# #     end_time_local = end_time_utc.astimezone(timezone)
# #     print(start_time_local, end_time_local)
# #     overlapping_hours = []
# #     for hour in store_hours[store_id]:
# #         if hour['day'] == start_time_local.weekday():
# #             ...

# from datetime import datetime, timedelta
# import pytz

# # Example data for store business hours
# store_hours = {
#     1481966498820158979: [
#         {"day": 4, "start_time": "00:00:00", "end_time": "00:10:00"},
#         {"day": 2, "start_time": "00:00:00", "end_time": "00:10:00"},
#         {"day": 0, "start_time": "00:00:00", "end_time": "00:10:00"},
#     ]
# }

# # Example data for store availability
# store_availability = {
#     1481966498820158979: [
#         {"status": "active", "timestamp_utc": "2023-03-22 15:59:39.388884"},
#         {"status": "inactive", "timestamp_utc": "2023-03-22 15:50:39.388884"},
#         {"status": "active", "timestamp_utc": "2023-03-22 15:11:39.388884"},
#     ]
# }

# # Example data for store timezones
# store_timezones = {
#     1481966498820158979: "Asia/Beirut",
#     5415949628544298339: "America/Boise",
#     3408529570017053440: "America/Denver",
# }

# # Get the store ID, start time, and end time of the last hour in UTC
# store_id = 1481966498820158979
# last_hour_utc = datetime.utcnow() - timedelta(hours=1)
# start_time_utc = datetime(
#     last_hour_utc.year, last_hour_utc.month, last_hour_utc.day, last_hour_utc.hour, 0, 0
# )
# end_time_utc = datetime(
#     last_hour_utc.year,
#     last_hour_utc.month,
#     last_hour_utc.day,
#     last_hour_utc.hour,
#     59,
#     59,
# )

# # Get the timezone of the store
# timezone_str = store_timezones.get(store_id, "America/Chicago")

# # Convert the start and end time of the last hour from UTC to the local time of the store
# start_time_local = start_time_utc.astimezone(pytz.timezone(timezone_str))
# end_time_local = end_time_utc.astimezone(pytz.timezone(timezone_str))

# # Get the store's business hours for the day of the last hour
# overlapping_hours = []
# for hour in store_hours[store_id]:
#     if hour["day"] == start_time_local.weekday():
#         start_str = f"{hour['day']} {hour['start_time']}"
#         end_str = f"{hour['day']} {hour['end_time']}"
#         start = datetime.strptime(start_str, "%w %H:%M:%S").time()
#         end = datetime.strptime(end_str, "%w %H:%M:%S").time()
#         # Check if the store's business hours overlap with the last hour
#         if start <= end_time_local.time() and end >= start_time_local.time():
#             # Calculate the duration of the overlapping period in minutes
#             duration = min(end_time_local.time(), end) - max(
#                 start_time_local.time(), start
#             )
#             duration_minutes = duration.seconds // 60
#             overlapping_hours.append(duration_minutes)

# # Calculate the total amount of time that the store was operational or "up" during the last hour
# total_minutes_up = sum(overlapping_hours)

# print(f"The store was up for {total_minutes_up} minutes during the last hour.")


# def uptime_last_hour(store_id):
#     # Example data for store business hours
#     store_hours = {
#         1481966498820158979: [
#             {"day": 4, "start_time": "00:00:00", "end_time": "00:10:00"},
#             {"day": 2, "start_time": "00:00:00", "end_time": "00:10:00"},
#             {"day": 0, "start_time": "00:00:00", "end_time": "00:10:00"},
#         ]
#     }

#     # Example data for store availability
#     store_availability = {
#         1481966498820158979: [
#             {"status": "active", "timestamp_utc": "2023-03-22 15:59:39.388884"},
#             {"status": "inactive", "timestamp_utc": "2023-03-22 15:50:39.388884"},
#             {"status": "active", "timestamp_utc": "2023-03-22 15:11:39.388884"},
#         ]
#     }

#     # Example data for store timezones
#     store_timezones = {
#         1481966498820158979: "Asia/Beirut",
#         5415949628544298339: "America/Boise",
#         3408529570017053440: "America/Denver",
#     }
#     last_hour_utc = datetime.utcnow() - timedelta(hours=1)
#     start_time_utc = datetime(
#         last_hour_utc.year,
#         last_hour_utc.month,
#         last_hour_utc.day,
#         last_hour_utc.hour,
#         0,
#         0,
#     )
#     end_time_utc = datetime(
#         last_hour_utc.year,
#         last_hour_utc.month,
#         last_hour_utc.day,
#         last_hour_utc.hour,
#         59,
#         59,
#     )

#     # Get the timezone of the store
#     timezone_str = store_timezones.get(store_id, "America/Chicago")

#     # Convert the start and end time of the last hour from UTC to the local time of the store
#     start_time_local = start_time_utc.astimezone(pytz.timezone(timezone_str))
#     end_time_local = end_time_utc.astimezone(pytz.timezone(timezone_str))

#     # Get the store's business hours for the day of the last hour
#     overlapping_hours = []
#     for hour in store_hours[store_id]:
#         if hour["day"] == start_time_local.weekday():
#             start_str = f"{hour['day']} {hour['start_time']}"
#             end_str = f"{hour['day']} {hour['end_time']}"
#             start = datetime.strptime(start_str, "%w %H:%M:%S").time()
#             end = datetime.strptime(end_str, "%w %H:%M:%S").time()
#             # Check if the store's business hours overlap with the last hour
#             if start <= end_time_local.time() and end >= start_time_local.time():
#                 # Calculate the duration of the overlapping period in minutes
#                 duration = min(end_time_local.time(), end) - max(
#                     start_time_local.time(), start
#                 )
#                 duration_minutes = duration.seconds // 60
#                 overlapping_hours.append(duration_minutes)

#     # Calculate the total amount of time that the store was operational or "up" during the last hour
#     total_minutes_up = sum(overlapping_hours)

#     print(f"The store was up for {total_minutes_up} minutes during the last hour.")


# """
# I have two collection store_status_history and store_hour_data
# create a mongodb aggregate pipeline to get last 7 days of store_status_history on the basis of
# store_hour_data which contains open and close time of the store with weekdays here is sample data for both
# of the collection

# store_status_history
# store_id,weekday,open,close
# 1481966498820158979,4,00:00:00,00:10:00
# 1481966498820158979,2,00:00:00,00:10:00

# store_id,status,timestamp_utc
# store_id,status,timestamp_utc
# 1481966498820158979,active,2023-01-22 12:09:39.388884 UTC
# 1481966498820158979,active,2023-01-24 09:06:42.605777 UTC
# """

# """
# Mongodb pipeline to only allow weekday 4 and hours from 00:00:00 00:10:00 using timestamp_utc on this
# collection with data
# store_id,status,timestamp_utc
# 1481966498820158979,active,2023-01-24 09:06:42.605777 UTC
# """

pipeline = [
    # match documents for the last 7 days
    {
        "$match": {
            "store_id": store_id,
            "timestamp_utc": {"$gte": start_date},
            "status": "active",
        }
    },
    {
        "$addFields": {
            "weekday": {"$dayOfWeek": "$timestamp_utc"},
            "hour": {"$hour": "$timestamp_utc"},
        }
    },
    # filter for specific weekdays and open/close times
    {
        "$match": {
            "$expr": {
                "$switch": {
                    "branches": [
                        {
                            "case": {
                                "$and": [
                                    {"$eq": ["$weekday", store_hours_data.get("day")]},
                                    {
                                        "$gte": [
                                            "$hour",
                                            get_24_hr(
                                                store_hours_data.get("start_time_local")
                                            ),
                                        ]
                                    },
                                    {
                                        "$lt": [
                                            "$hour",
                                            get_24_hr(
                                                store_hours_data.get("end_time_local")
                                            ),
                                        ]
                                    },
                                ]
                            },
                            "then": True,
                        }8139926242460185114
                        for store_hours_data in db.store_hours_data.find(
                            {"store_id": store_id}8139926242460185114
                        )
                    ],
                    "default": False,
                }
            }
        }
    },
]
